-- Creation of the VendiCose_SPA database
CREATE DATABASE IF NOT EXISTS VendiCose_SPA;

-- Use of the database
USE VendiCose_SPA;

-- 
CREATE TABLE IF NOT EXISTS Category (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(100) NOT NULL,
    restock_threshold INT NOT NULL
);

-- Creation of the Product table
CREATE TABLE IF NOT EXISTS Product (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(100) NOT NULL,
    category_id INT NOT NULL,
    FOREIGN KEY (category_id) REFERENCES Category(category_id)
);

-- Creation of the Warehouse table
CREATE TABLE IF NOT EXISTS Warehouse (
    warehouse_id INT AUTO_INCREMENT PRIMARY KEY,
    warehouse_name VARCHAR(100) NOT NULL,
    address VARCHAR(255) NOT NULL
);

-- Creation of the Store table
CREATE TABLE IF NOT EXISTS Store (
    store_id INT AUTO_INCREMENT PRIMARY KEY,
    store_name VARCHAR(100) NOT NULL,
    warehouse_id INT NOT NULL,
    FOREIGN KEY (warehouse_id) REFERENCES Warehouse(warehouse_id)
);

-- Creation of the Stock table
CREATE TABLE IF NOT EXISTS Stock (
    warehouse_id INT NOT NULL,
    product_id INT NOT NULL,
    available_quantity INT NOT NULL,
    PRIMARY KEY (warehouse_id, product_id),
    FOREIGN KEY (warehouse_id) REFERENCES Warehouse(warehouse_id),
    FOREIGN KEY (product_id) REFERENCES Product(product_id)
);

-- Creation of the Transaction table
CREATE TABLE IF NOT EXISTS Transaction (
    transaction_id INT AUTO_INCREMENT PRIMARY KEY,
    store_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity_sold INT NOT NULL,
    transaction_date DATETIME NOT NULL,
    FOREIGN KEY (store_id) REFERENCES Store(store_id),
    FOREIGN KEY (product_id) REFERENCES Product(product_id)
);
INSERT INTO Category (category_id, category_name, restock_threshold) VALUES
(1, 'Alimentari_1', 16),
(2, 'Cosmetica_2', 17),
(3, 'Elettronica_3', 34),
(4, 'Abbigliamento_4', 45),
(5, 'Giocattoli_5', 17),
(6, 'Sport_6', 39),
(7, 'Ufficio_7', 18),
(8, 'Farmaci_8', 21),
(9, 'Casa_9', 11),
(10, 'Giardinaggio_10', 29),
(11, 'Auto_11', 25),
(12, 'Bambini_12', 39),
(13, 'Libri_13', 49),
(14, 'Musica_14', 33),
(15, 'Bevande_15', 39),
(16, 'Cucina_16', 17),
(17, 'Illuminazione_17', 11),
(18, 'Animali_18', 26),
(19, 'Viaggi_19', 17),
(20, 'Hobby_20', 41),
(21, 'Arte_21', 14),
(22, 'Strumenti_22', 34),
(23, 'Pulizia_23', 45),
(24, 'Tecnologia_24', 18),
(25, 'Salute_25', 46),
(26, 'Tempo Libero_26', 18),
(27, 'Bellezza_27', 37),
(28, 'Gioielli_28', 48),
(29, 'Accessori_29', 23),
(30, 'Moda_30', 14),
(31, 'Outdoor_31', 18),
(32, 'Energie_32', 41),
(33, 'Elettrodomestici_33', 13),
(34, 'Digitale_34', 20),
(35, 'Sicurezza_35', 28),
(36, 'Gaming_36', 47),
(37, 'Fotografia_37', 32),
(38, 'Design_38', 31),
(39, 'Smart Home_39', 27),
(40, 'Altro_40', 33),
(41, 'Alimentari_41', 26),
(42, 'Cosmetica_42', 36),
(43, 'Elettronica_43', 20),
(44, 'Abbigliamento_44', 17),
(45, 'Giocattoli_45', 47),
(46, 'Sport_46', 37),
(47, 'Ufficio_47', 35),
(48, 'Farmaci_48', 42),
(49, 'Casa_49', 23),
(50, 'Giardinaggio_50', 21),
(51, 'Auto_51', 14),
(52, 'Bambini_52', 44),
(53, 'Libri_53', 17),
(54, 'Musica_54', 37),
(55, 'Bevande_55', 40),
(56, 'Cucina_56', 48),
(57, 'Illuminazione_57', 37),
(58, 'Animali_58', 31),
(59, 'Viaggi_59', 14),
(60, 'Hobby_60', 45),
(61, 'Arte_61', 21),
(62, 'Strumenti_62', 10),
(63, 'Pulizia_63', 34),
(64, 'Tecnologia_64', 11),
(65, 'Salute_65', 23),
(66, 'Tempo Libero_66', 44),
(67, 'Bellezza_67', 25),
(68, 'Gioielli_68', 29),
(69, 'Accessori_69', 49),
(70, 'Moda_70', 46),
(71, 'Outdoor_71', 10),
(72, 'Energie_72', 29),
(73, 'Elettrodomestici_73', 41),
(74, 'Digitale_74', 50),
(75, 'Sicurezza_75', 31),
(76, 'Gaming_76', 14),
(77, 'Fotografia_77', 25),
(78, 'Design_78', 19),
(79, 'Smart Home_79', 20),
(80, 'Altro_80', 11),
(81, 'Alimentari_81', 30),
(82, 'Cosmetica_82', 30),
(83, 'Elettronica_83', 23),
(84, 'Abbigliamento_84', 19),
(85, 'Giocattoli_85', 18),
(86, 'Sport_86', 50),
(87, 'Ufficio_87', 37),
(88, 'Farmaci_88', 34),
(89, 'Casa_89', 15),
(90, 'Giardinaggio_90', 28),
(91, 'Auto_91', 17),
(92, 'Bambini_92', 16),
(93, 'Libri_93', 43),
(94, 'Musica_94', 23),
(95, 'Bevande_95', 15),
(96, 'Cucina_96', 49),
(97, 'Illuminazione_97', 49),
(98, 'Animali_98', 41),
(99, 'Viaggi_99', 14),
(100, 'Hobby_100', 28);

INSERT INTO Product (product_id, product_name, category_id) VALUES
(1, 'Pasta_1', 27),
(2, 'Shampoo_2', 17),
(3, 'Smartphone_3', 90),
(4, 'Maglietta_4', 22),
(5, 'Bambola_5', 74),
(6, 'Pallone_6', 76),
(7, 'Notebook_7', 71),
(8, 'Paracetamolo_8', 34),
(9, 'Cuscino_9', 87),
(10, 'Vanga_10', 13),
(11, 'Olio motore_11', 2),
(12, 'Lampada_12', 80),
(13, 'Vino_13', 52),
(14, 'Robot Cucina_14', 3),
(15, 'Scarpe_15', 19),
(16, 'Zaino_16', 73),
(17, 'Aspirina_17', 15),
(18, 'Televisore_18', 7),
(19, 'Tenda_19', 73),
(20, 'Puzzle_20', 85),
(21, 'Penna_21', 24),
(22, 'Jeans_22', 48),
(23, 'Cappotto_23', 28),
(24, 'Caffè_24', 27),
(25, 'Bicicletta_25', 8),
(26, 'Orologio_26', 63),
(27, 'Frullatore_27', 96),
(28, 'Stereo_28', 88),
(29, 'Libro_29', 29),
(30, 'Giocattolo_30', 19),
(31, 'Videogioco_31', 37),
(32, 'Occhiali_32', 81),
(33, 'Portatile_33', 10),
(34, 'Borsetta_34', 15),
(35, 'Macchina Fotografica_35', 48),
(36, 'Cuffie_36', 15),
(37, 'Monitor_37', 29),
(38, 'Sedia_38', 34),
(39, 'Barbecue_39', 59),
(40, 'Tappeto_40', 90),
(41, 'Specchio_41', 65),
(42, 'Borsa_42', 17),
(43, 'Ferro da Stiro_43', 60),
(44, 'Trapano_44', 48),
(45, 'Teiera_45', 63),
(46, 'Pasta_46', 5),
(47, 'Shampoo_47', 44),
(48, 'Smartphone_48', 7),
(49, 'Maglietta_49', 45),
(50, 'Bambola_50', 81),
(51, 'Pallone_51', 82),
(52, 'Notebook_52', 49),
(53, 'Paracetamolo_53', 7),
(54, 'Cuscino_54', 51),
(55, 'Vanga_55', 15),
(56, 'Olio motore_56', 9),
(57, 'Lampada_57', 24),
(58, 'Vino_58', 71),
(59, 'Robot Cucina_59', 21),
(60, 'Scarpe_60', 74),
(61, 'Zaino_61', 26),
(62, 'Aspirina_62', 28),
(63, 'Televisore_63', 17),
(64, 'Tenda_64', 38),
(65, 'Puzzle_65', 71),
(66, 'Penna_66', 3),
(67, 'Jeans_67', 63),
(68, 'Cappotto_68', 76),
(69, 'Caffè_69', 48),
(70, 'Bicicletta_70', 18),
(71, 'Orologio_71', 4),
(72, 'Frullatore_72', 26),
(73, 'Stereo_73', 50),
(74, 'Libro_74', 71),
(75, 'Giocattolo_75', 27),
(76, 'Videogioco_76', 87),
(77, 'Occhiali_77', 73),
(78, 'Portatile_78', 95),
(79, 'Borsetta_79', 70),
(80, 'Macchina Fotografica_80', 5),
(81, 'Cuffie_81', 6),
(82, 'Monitor_82', 15),
(83, 'Sedia_83', 73),
(84, 'Barbecue_84', 68),
(85, 'Tappeto_85', 74),
(86, 'Specchio_86', 52),
(87, 'Borsa_87', 1),
(88, 'Ferro da Stiro_88', 84),
(89, 'Trapano_89', 44),
(90, 'Teiera_90', 12),
(91, 'Pasta_91', 40),
(92, 'Shampoo_92', 67),
(93, 'Smartphone_93', 90),
(94, 'Maglietta_94', 86),
(95, 'Bambola_95', 38),
(96, 'Pallone_96', 96),
(97, 'Notebook_97', 29),
(98, 'Paracetamolo_98', 54),
(99, 'Cuscino_99', 63),
(100, 'Vanga_100', 74);

INSERT INTO Warehouse (warehouse_id, warehouse_name, address) VALUES
(1, 'Central Warehouse', 'Address 39, Milan'),
(2, 'North Warehouse', 'Address 86, Turin'),
(3, 'South Warehouse', 'Address 93, Turin'),
(4, 'East Warehouse', 'Address 16, Florence'),
(5, 'West Warehouse', 'Address 97, Turin'),
(6, 'Rome Depot', 'Address 63, Turin'),
(7, 'Milan Depot', 'Address 36, Turin'),
(8, 'Naples Depot', 'Address 77, Turin'),
(9, 'Turin Hub', 'Address 82, Florence'),
(10, 'Bologna Hub', 'Address 58, Turin'),
(11, 'Florence Warehouse', 'Address 86, Rome'),
(12, 'Palermo Warehouse', 'Address 31, Rome'),
(13, 'Verona Logistics Center', 'Address 74, Florence'),
(14, 'Genoa Logistics Center', 'Address 49, Turin'),
(15, 'Bari Warehouse', 'Address 74, Milan'),
(16, 'Padua Depot', 'Address 92, Milan'),
(17, 'Venice Warehouse', 'Address 65, Turin'),
(18, 'Catania Hub', 'Address 14, Florence'),
(19, 'Bergamo Warehouse', 'Address 60, Florence'),
(20, 'Brescia Warehouse', 'Address 1, Rome'),
(21, 'Trieste Warehouse', 'Address 34, Rome'),
(22, 'Parma Logistics Center', 'Address 12, Florence'),
(23, 'Reggio Emilia Warehouse', 'Address 21, Milan'),
(24, 'Rimini Hub', 'Address 9, Rome'),
(25, 'Perugia Depot', 'Address 6, Florence'),
(26, 'Messina Warehouse', 'Address 43, Milan'),
(27, 'Lecce Hub', 'Address 2, Rome'),
(28, 'Trento Warehouse', 'Address 43, Milan'),
(29, 'Bolzano Warehouse', 'Address 62, Florence'),
(30, 'Livorno Depot', 'Address 68, Rome'),
(31, 'Pescara Warehouse', 'Address 5, Florence'),
(32, 'Ancona Warehouse', 'Address 2, Milan'),
(33, 'Modena Warehouse', 'Address 21, Florence'),
(34, 'Ravenna Depot', 'Address 49, Rome'),
(35, 'Grosseto Warehouse', 'Address 47, Milan'),
(36, 'Novara Logistics Center', 'Address 2, Milan'),
(37, 'Arezzo Warehouse', 'Address 62, Rome'),
(38, 'Foggia Depot', 'Address 44, Rome'),
(39, 'Cagliari Warehouse', 'Address 24, Rome'),
(40, 'Sassari Hub', 'Address 98, Florence'),
(41, 'Olbia Warehouse', 'Address 53, Milan'),
(42, 'Asti Depot', 'Address 84, Rome'),
(43, 'Siena Warehouse', 'Address 3, Milan'),
(44, 'Latina Logistics Center', 'Address 83, Turin'),
(45, 'Taranto Warehouse', 'Address 10, Florence'),
(46, 'Brindisi Warehouse', 'Address 3, Turin'),
(47, 'Cosenza Depot', 'Address 75, Florence'),
(48, 'Potenza Warehouse', 'Address 62, Rome'),
(49, 'Viterbo Logistics Center', 'Address 77, Rome'),
(50, 'L_Aquila Warehouse', 'Address 79, Florence'),
(51, 'Campobasso Hub', 'Address 88, Turin'),
(52, 'Catanzaro Warehouse', 'Address 94, Rome'),
(53, 'Matera Depot', 'Address 88, Turin'),
(54, 'Pisa Logistics Center', 'Address 57, Turin'),
(55, 'Lucca Warehouse', 'Address 89, Rome'),
(56, 'Lecce Warehouse', 'Address 72, Turin'),
(57, 'La Spezia Depot', 'Address 27, Florence'),
(58, 'Cremona Warehouse', 'Address 90, Turin'),
(59, 'Mantua Warehouse', 'Address 3, Florence'),
(60, 'Udine Depot', 'Address 13, Florence'),
(61, 'Ferrara Warehouse', 'Address 50, Rome'),
(62, 'Monza Hub', 'Address 27, Milan'),
(63, 'Alessandria Warehouse', 'Address 52, Turin'),
(64, 'Ragusa Depot', 'Address 36, Florence'),
(65, 'Central Warehouse', 'Address 54, Milan'),
(66, 'North Warehouse', 'Address 87, Rome'),
(67, 'South Warehouse', 'Address 10, Milan'),
(68, 'East Warehouse', 'Address 18, Milan'),
(69, 'West Warehouse', 'Address 39, Turin'),
(70, 'Rome Depot', 'Address 95, Turin'),
(71, 'Milan Depot', 'Address 7, Turin'),
(72, 'Naples Depot', 'Address 15, Milan'),
(73, 'Turin Hub', 'Address 79, Milan'),
(74, 'Bologna Hub', 'Address 94, Turin'),
(75, 'Florence Warehouse', 'Address 100, Florence'),
(76, 'Palermo Warehouse', 'Address 4, Turin'),
(77, 'Verona Logistics Center', 'Address 22, Milan'),
(78, 'Genoa Logistics Center', 'Address 69, Turin'),
(79, 'Bari Warehouse', 'Address 65, Florence'),
(80, 'Padua Depot', 'Address 84, Turin'),
(81, 'Venice Warehouse', 'Address 26, Florence'),
(82, 'Catania Hub', 'Address 72, Turin'),
(83, 'Bergamo Warehouse', 'Address 68, Turin'),
(84, 'Brescia Warehouse', 'Address 43, Turin'),
(85, 'Trieste Warehouse', 'Address 100, Milan'),
(86, 'Parma Logistics Center', 'Address 57, Milan'),
(87, 'Reggio Emilia Warehouse', 'Address 38, Florence'),
(88, 'Rimini Hub', 'Address 48, Turin'),
(89, 'Perugia Depot', 'Address 43, Milan'),
(90, 'Messina Warehouse', 'Address 13, Florence'),
(91, 'Lecce Hub', 'Address 43, Rome'),
(92, 'Trento Warehouse', 'Address 6, Florence'),
(93, 'Bolzano Warehouse', 'Address 69, Rome'),
(94, 'Livorno Depot', 'Address 58, Rome'),
(95, 'Pescara Warehouse', 'Address 65, Turin'),
(96, 'Ancona Warehouse', 'Address 28, Milan'),
(97, 'Modena Warehouse', 'Address 14, Florence'),
(98, 'Ravenna Depot', 'Address 3, Florence'),
(99, 'Grosseto Warehouse', 'Address 27, Milan'),
(100, 'Novara Logistics Center', 'Address 3, Rome');

INSERT INTO Store (store_id, store_name, warehouse_id) VALUES
(1, 'Rome Central Store', 97),
(2, 'Milan Cathedral Store', 58),
(3, 'Naples Seafront Store', 43),
(4, 'Turin Porta Nuova Store', 74),
(5, 'Florence Uffizi Store', 20),
(6, 'Palermo Station Store', 52),
(7, 'Bologna Fair Store', 65),
(8, 'Verona Arena Store', 99),
(9, 'Genoa Port Store', 52),
(10, 'Bari Central Store', 48),
(11, 'Padua Meadow Store', 7),
(12, 'Venice San Marco Store', 51),
(13, 'Catania Central Store', 15),
(14, 'Bergamo Upper City Store', 59),
(15, 'Brescia Central Store', 98),
(16, 'Trieste Piazza Store', 85),
(17, 'Parma Central Store', 85),
(18, 'Rimini Marina Store', 81),
(19, 'Perugia Fountain Store', 4),
(20, 'Messina Cathedral Store', 22),
(21, 'Lecce Baroque Store', 54),
(22, 'Trento Mountain Store', 1),
(23, 'Bolzano Dolomites Store', 44),
(24, 'Livorno Port Store', 85),
(25, 'Pescara Sea Store', 72),
(26, 'Ancona Central Store', 91),
(27, 'Modena Tower Store', 31),
(28, 'Ravenna Art Store', 13),
(29, 'Grosseto Central Store', 95),
(30, 'Novara Dome Store', 63),
(31, 'Arezzo Central Store', 72),
(32, 'Foggia Central Store', 69),
(33, 'Cagliari Castle Store', 41),
(34, 'Sassari Central Store', 45),
(35, 'Olbia Port Store', 54),
(36, 'Asti Palio Store', 95),
(37, 'Siena Square Store', 20),
(38, 'Latina Central Store', 8),
(39, 'Taranto Sea Store', 52),
(40, 'Brindisi Port Store', 49),
(41, 'Cosenza Central Store', 67),
(42, 'Potenza Central Store', 44),
(43, 'Viterbo Spa Store', 4),
(44, 'L_Aquila Fortress Store', 8),
(45, 'Campobasso Central Store', 53),
(46, 'Catanzaro Sea Store', 52),
(47, 'Matera Sassi Store', 99),
(48, 'Pisa Tower Store', 2),
(49, 'Lucca Walls Store', 38),
(50, 'La Spezia Port Store', 7),
(51, 'Cremona Cathedral Store', 2),
(52, 'Mantua Central Store', 88),
(53, 'Udine Castle Store', 94),
(54, 'Ferrara Castle Store', 61),
(55, 'Monza Villa Store', 8),
(56, 'Alessandria Central Store', 13),
(57, 'Ragusa Central Store', 43),
(58, 'Rome Central Store', 65),
(59, 'Milan Cathedral Store', 8),
(60, 'Naples Seafront Store', 52),
(61, 'Turin Porta Nuova Store', 39),
(62, 'Florence Uffizi Store', 2),
(63, 'Palermo Station Store', 1),
(64, 'Bologna Fair Store', 96),
(65, 'Verona Arena Store', 33),
(66, 'Genoa Port Store', 56),
(67, 'Bari Central Store', 30),
(68, 'Padua Meadow Store', 3),
(69, 'Venice San Marco Store', 23),
(70, 'Catania Central Store', 61),
(71, 'Bergamo Upper City Store', 84),
(72, 'Brescia Central Store', 83),
(73, 'Trieste Piazza Store', 44),
(74, 'Parma Central Store', 60),
(75, 'Rimini Marina Store', 53),
(76, 'Perugia Fountain Store', 99),
(77, 'Messina Cathedral Store', 66),
(78, 'Lecce Baroque Store', 24),
(79, 'Trento Mountain Store', 12),
(80, 'Bolzano Dolomites Store', 13),
(81, 'Livorno Port Store', 83),
(82, 'Pescara Sea Store', 88),
(83, 'Ancona Central Store', 10),
(84, 'Modena Tower Store', 60),
(85, 'Ravenna Art Store', 55),
(86, 'Grosseto Central Store', 80),
(87, 'Novara Dome Store', 93),
(88, 'Arezzo Central Store', 90),
(89, 'Foggia Central Store', 61),
(90, 'Cagliari Castle Store', 96),
(91, 'Sassari Central Store', 44),
(92, 'Olbia Port Store', 8),
(93, 'Asti Palio Store', 17),
(94, 'Siena Square Store', 100),
(95, 'Latina Central Store', 9),
(96, 'Taranto Sea Store', 6),
(97, 'Brindisi Port Store', 53),
(98, 'Cosenza Central Store', 83),
(99, 'Potenza Central Store', 2),
(100, 'Viterbo Spa Store', 42);

INSERT INTO Stock (warehouse_id, product_id, available_quantity) VALUES
(24, 25, 407),
(44, 54, 268),
(57, 31, 296),
(6, 50, 10),
(21, 82, 8),
(88, 49, 290),
(98, 42, 33),
(36, 83, 474),
(99, 72, 206),
(98, 82, 234),
(87, 25, 443),
(54, 42, 132),
(51, 14, 27),
(5, 17, 416),
(60, 12, 119),
(74, 90, 332),
(41, 52, 41),
(2, 2, 316),
(32, 52, 497),
(42, 98, 358),
(29, 70, 92),
(27, 85, 426),
(6, 17, 369),
(49, 21, 249),
(72, 67, 357),
(87, 11, 57),
(1, 79, 68),
(27, 77, 481),
(20, 70, 114),
(1, 61, 271),
(63, 86, 88),
(39, 1, 116),
(39, 78, 80),
(99, 14, 483),
(78, 75, 185),
(43, 43, 459),
(69, 58, 423),
(90, 24, 485),
(36, 9, 329),
(47, 97, 459),
(18, 68, 47),
(100, 40, 160),
(63, 76, 37),
(34, 23, 381),
(71, 80, 203),
(3, 81, 281),
(66, 74, 43),
(51, 33, 460),
(19, 5, 394),
(82, 79, 299),
(51, 46, 393),
(6, 16, 161),
(14, 29, 405),
(81, 62, 363),
(67, 63, 213),
(28, 18, 490),
(44, 80, 457),
(26, 22, 10),
(65, 77, 137),
(1, 10, 84),
(83, 43, 372),
(84, 8, 463),
(100, 66, 317),
(44, 35, 41),
(8, 31, 290),
(36, 26, 185),
(73, 69, 220),
(36, 69, 156),
(98, 25, 303),
(85, 66, 418),
(69, 42, 171),
(55, 54, 375),
(79, 81, 77),
(36, 35, 210),
(45, 17, 204),
(86, 69, 291),
(74, 29, 36),
(4, 70, 415),
(18, 100, 56),
(46, 100, 209),
(38, 31, 500),
(99, 57, 242),
(34, 82, 404),
(71, 4, 422),
(52, 48, 104),
(81, 95, 322),
(65, 78, 396),
(16, 13, 105),
(20, 31, 40),
(64, 4, 343),
(88, 31, 266),
(71, 66, 319),
(73, 88, 296),
(79, 22, 30),
(91, 25, 94),
(86, 12, 467),
(58, 12, 41),
(79, 99, 0),
(7, 67, 279),
(46, 36, 50);

INSERT INTO Transaction (transaction_id, store_id, product_id, quantity_sold, transaction_date) VALUES
(1, 6, 67, 7, '2024-03-12 00:13:25'),
(2, 13, 48, 22, '2024-05-26 22:25:46'),
(3, 92, 72, 29, '2024-03-06 20:55:19'),
(4, 50, 20, 39, '2024-01-31 17:53:31'),
(5, 8, 34, 6, '2024-03-19 21:59:06'),
(6, 71, 86, 4, '2024-10-28 20:06:40'),
(7, 62, 99, 39, '2024-06-28 11:48:21'),
(8, 49, 73, 26, '2024-01-05 13:48:57'),
(9, 43, 89, 17, '2024-12-22 22:25:49'),
(10, 50, 74, 12, '2024-04-04 05:08:14'),
(11, 54, 78, 36, '2024-01-23 21:07:20'),
(12, 74, 30, 1, '2024-02-04 21:17:39'),
(13, 24, 36, 5, '2024-12-22 19:52:03'),
(14, 97, 37, 10, '2024-12-18 17:00:24'),
(15, 92, 8, 7, '2024-04-26 13:31:09'),
(16, 16, 6, 37, '2024-01-03 20:31:30'),
(17, 89, 85, 25, '2024-03-08 03:47:28'),
(18, 93, 61, 11, '2024-12-15 11:46:53'),
(19, 71, 84, 41, '2024-10-22 16:55:43'),
(20, 91, 43, 41, '2024-04-12 05:41:33'),
(21, 4, 3, 24, '2024-11-26 22:41:52'),
(22, 20, 49, 44, '2024-06-22 05:13:07'),
(23, 98, 16, 50, '2024-07-30 22:00:33'),
(24, 7, 38, 31, '2024-05-15 03:53:45'),
(25, 95, 50, 47, '2024-08-20 04:52:19'),
(26, 65, 27, 43, '2024-11-18 20:56:28'),
(27, 13, 55, 27, '2024-01-09 06:30:59'),
(28, 88, 35, 13, '2024-08-17 06:13:39'),
(29, 88, 67, 27, '2024-01-18 08:56:47'),
(30, 58, 97, 7, '2024-05-18 08:08:53'),
(31, 56, 53, 25, '2024-12-22 23:54:41'),
(32, 29, 96, 43, '2024-08-01 14:33:45'),
(33, 3, 64, 35, '2024-09-10 07:47:03'),
(34, 90, 86, 44, '2024-09-23 04:24:28'),
(35, 79, 72, 48, '2024-04-05 00:46:25'),
(36, 36, 71, 35, '2024-04-25 07:42:11'),
(37, 34, 61, 40, '2024-10-28 13:24:24'),
(38, 58, 10, 1, '2024-11-06 13:34:02'),
(39, 76, 43, 16, '2024-01-08 02:43:03'),
(40, 80, 21, 8, '2024-09-26 17:48:32'),
(41, 53, 63, 17, '2024-01-20 14:44:06'),
(42, 85, 86, 27, '2024-03-18 12:56:08'),
(43, 3, 63, 43, '2024-11-26 00:25:58'),
(44, 48, 79, 29, '2024-07-19 22:07:02'),
(45, 80, 12, 36, '2024-09-18 02:14:53'),
(46, 69, 46, 37, '2024-05-03 11:45:53'),
(47, 73, 14, 47, '2024-05-04 10:00:52'),
(48, 4, 5, 17, '2024-06-11 10:47:39'),
(49, 71, 8, 33, '2024-11-05 21:54:49'),
(50, 6, 7, 26, '2024-01-18 04:24:40'),
(51, 48, 13, 3, '2024-06-07 19:48:04'),
(52, 49, 5, 23, '2024-03-16 16:47:00'),
(53, 74, 24, 10, '2024-02-20 18:18:51'),
(54, 9, 99, 14, '2024-12-08 16:13:16'),
(55, 67, 34, 4, '2024-09-19 21:39:19'),
(56, 28, 76, 42, '2024-01-20 21:07:39'),
(57, 98, 3, 31, '2024-04-25 23:51:46'),
(58, 58, 18, 34, '2024-07-27 12:13:50'),
(59, 34, 74, 8, '2024-02-26 10:06:03'),
(60, 64, 48, 4, '2024-01-10 12:51:28'),
(61, 14, 95, 42, '2024-01-26 14:33:06'),
(62, 47, 11, 48, '2024-03-19 16:53:26'),
(63, 96, 27, 31, '2024-09-23 20:16:32'),
(64, 41, 52, 27, '2024-01-21 06:43:09'),
(65, 29, 42, 35, '2024-12-08 10:19:27'),
(66, 31, 81, 18, '2024-05-31 13:02:17'),
(67, 78, 58, 5, '2024-10-04 21:26:03'),
(68, 2, 97, 29, '2024-11-21 17:23:57'),
(69, 35, 55, 8, '2024-05-04 13:03:39'),
(70, 97, 29, 29, '2024-08-16 16:29:44'),
(71, 30, 95, 45, '2024-09-15 18:23:16'),
(72, 74, 5, 45, '2024-08-19 03:33:45'),
(73, 90, 12, 8, '2024-01-07 18:54:35'),
(74, 6, 78, 32, '2024-05-27 09:47:02'),
(75, 65, 15, 35, '2024-12-12 23:13:30'),
(76, 86, 31, 35, '2024-07-12 11:20:57'),
(77, 24, 45, 15, '2024-03-25 10:14:48'),
(78, 46, 91, 29, '2024-10-09 13:28:00'),
(79, 69, 39, 12, '2024-04-18 01:09:07'),
(80, 82, 27, 46, '2024-03-13 03:29:10'),
(81, 50, 69, 49, '2024-05-28 14:51:03'),
(82, 79, 54, 28, '2024-06-05 09:35:25'),
(83, 79, 59, 36, '2024-11-16 21:00:37'),
(84, 56, 81, 42, '2024-10-20 10:27:02'),
(85, 63, 6, 26, '2024-05-17 08:41:51'),
(86, 46, 12, 29, '2024-04-24 10:14:48'),
(87, 79, 5, 4, '2024-12-12 11:45:43'),
(88, 96, 81, 33, '2024-02-09 14:22:31'),
(89, 76, 42, 15, '2024-03-15 14:45:25'),
(90, 67, 37, 5, '2024-06-18 04:35:58'),
(91, 37, 15, 39, '2024-12-06 13:51:34'),
(92, 64, 14, 28, '2024-01-12 06:51:03'),
(93, 15, 27, 38, '2024-12-28 06:47:24'),
(94, 56, 18, 27, '2024-11-23 11:13:42'),
(95, 65, 88, 27, '2024-04-13 17:02:26'),
(96, 87, 49, 43, '2024-07-30 13:01:32'),
(97, 46, 51, 27, '2024-03-26 09:21:09'),
(98, 46, 14, 17, '2024-08-24 21:32:20'),
(99, 85, 3, 5, '2024-01-12 17:43:08'),
(100, 77, 60, 28, '2024-03-20 18:22:33');

/*Whenever a product is sold in a store, the following query
 is specified to update the reference tables*/
 -- 1st example
START TRANSACTION;
-- Creation of a sample database
CREATE DATABASE IF NOT EXISTS TestDB;
USE TestDB;

-- Creation of the Store table
CREATE TABLE IF NOT EXISTS Store (
    store_id INT PRIMARY KEY,
    warehouse_id INT
);

-- Creation of the Stock table
CREATE TABLE IF NOT EXISTS Stock (
    warehouse_id INT,
    product_id INT,
    available_quantity INT,
    PRIMARY KEY (warehouse_id, product_id)
);

-- Inserting Sample Data
INSERT INTO Store (store_id, warehouse_id)
VALUES
    (1, 10),
    (2, 20),
    (3, 30),
    (5, 40); 

INSERT INTO Stock (warehouse_id, product_id, available_quantity)
VALUES
    (40, 101, 40), -- This is the record that will be updated
    (20, 102, 100),
    (30, 103, 75);

-- Verification of the initial situation
SELECT * FROM Stock;
SELECT * FROM Store;

-- Execution of the update query
UPDATE Stock
SET available_quantity = available_quantity - 10
WHERE warehouse_id = 40
AND product_id = 101;

-- Verification of the situation after the update
SELECT * FROM Stock;

ROLLBACK;
DROP DATABASE TestDB;


-- 1st request. 
-- Check how many units of a product are in a given warehouse
SELECT 
    s.warehouse_id,
    w.warehouse_name,
    s.product_id,
    p.product_name,
    s.available_quantity
FROM 
    Stock as s
JOIN 
    Warehouse as w ON s.warehouse_id = w.warehouse_id
JOIN 
    Product as p ON s.product_id = p.product_id
WHERE 
    s.warehouse_id = (warehouse_id)
    AND s.product_id = (product_id);
    
    -- 2nd example
SELECT 
    s.warehouse_id,
    w.warehouse_name,
    s.product_id,
    p.product_name,
    s.available_quantity
FROM 
    Stock as s
INNER JOIN 
    Warehouse as w ON s.warehouse_id = w.warehouse_id
INNER JOIN 
    Product as p ON s.product_id = p.product_id
WHERE 
    s.warehouse_id = 39
    AND s.product_id = 1;
    
    -- 2. request
    -- Check all products and warehouses that need restocking
    SELECT 
    s.warehouse_id,
    w.warehouse_name,
    s.product_id,
    p.product_name,
    s.available_quantity,
    c.restock_threshold
FROM 
    Stock as s
INNER JOIN 
    Warehouse as w ON s.warehouse_id = w.warehouse_id
INNER JOIN 
    Product as p ON s.product_id = p.product_id
INNER JOIN 
    Category as c ON p.category_id = c.category_id
WHERE 
    s.warehouse_id = (warehouse_id)
    AND s.available_quantity < c.restock_threshold;
    
-- 3rd example
SELECT 
    s.warehouse_id,
    w.warehouse_name,
    s.product_id,
    p.product_name,
    s.available_quantity,
    c.restock_threshold
FROM 
    Stock as s
JOIN 
    Warehouse w ON s.warehouse_id = w.warehouse_id
INNER JOIN 
    Product as p ON s.product_id = p.product_id
INNER JOIN 
    Category as c ON p.category_id = c.category_id
WHERE 
s.available_quantity < c.restock_threshold;


    
    
    
    



   